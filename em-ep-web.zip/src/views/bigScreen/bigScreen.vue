
<template>
  <div>
    <iframe src= 'https://www.makeapie.com/explore.html#sort=rank~timeframe=all~author=all'  width="100%" height="830px" frameborder="0" scrolling="auto" id="iframename" name="iframename" ></iframe>
  </div>
</template>

<script>

export default {
  name: "NifiTool",
  props: {},
  data() {
    return {
        eurekaUrl:''
    };
  },
  methods: {},
};
</script>


<style scoped>
</style>

