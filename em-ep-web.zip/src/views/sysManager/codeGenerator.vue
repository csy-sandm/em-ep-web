
<template>
  <div>
    <iframe src= 'http://127.0.0.1:8068/common/generator'  width="100%" height="830px" frameborder="0" scrolling="auto" id="iframename" name="iframename" ></iframe>
  </div>
  <!-- <div> <iframe src="https://www.baidu.com/" width="100%" height="800" frameborder="0" scrolling="auto" id="iframename" name="iframename"></iframe> </div>-->
</template>



<script>

export default {
  name: "NifiTool",
  props: {},
  data() {
    return {
        eurekaUrl:''
    };
  },
  methods: {},
};
</script>


<style scoped>
</style>

