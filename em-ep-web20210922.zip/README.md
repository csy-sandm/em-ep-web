# EM-EP-WEB

## 项目运行
```
yarn install
yarn serve
```
## 蓝狐高保真地址

https://lanhuapp.com/url/EP7F8-6nC32

## DNS更新缓存命令
ipconfig /flushdns